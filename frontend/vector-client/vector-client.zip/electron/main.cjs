const { app, BrowserWindow } = require('electron');
const path = require('node:path');
const { registerVectorCryptoIpc } = require('./crypto/vectorCryptoIpc.cjs');

const vectorProfile = process.env.VECTOR_PROFILE;

if (vectorProfile) {
  const safeProfileName = vectorProfile.replace(/[^a-zA-Z0-9_-]/g, '_');
  app.setPath(
    'userData',
    path.join(app.getPath('appData'), `vector-client-${safeProfileName}`)
  );
}

const createWindow = () => {
  const mainWindow = new BrowserWindow({
    width: 1320,
    height: 860,
    minWidth: 1040,
    minHeight: 700,
    backgroundColor: '#111214',
    title: 'Vector Messenger',
    titleBarStyle: 'hiddenInset',
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: false,
    },
  });

  const devServerUrl = process.env.VITE_DEV_SERVER_URL;

  if (devServerUrl) {
    mainWindow.loadURL(devServerUrl);
    mainWindow.webContents.openDevTools({ mode: 'detach' });
    return;
  }

  mainWindow.loadFile(path.join(__dirname, '..', 'dist', 'index.html'));
};

app.whenReady().then(() => {
  registerVectorCryptoIpc();
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});